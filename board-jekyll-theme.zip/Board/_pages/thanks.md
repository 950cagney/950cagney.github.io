---
title: Thank you
subtitle: Your message was sent successfully.
description: Board is a stylish full-width masonry grid theme.
featured_image: /images/demo/about.jpg
---

![](/images/demo/about.jpg)

Please note, this contact form is for demo purposes only and is not monitored. Please contact us [via our website](https://jekyllthemes.io) if you need support.